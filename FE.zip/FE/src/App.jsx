import { Suspense, lazy } from "react"
import "./App.css"

// Lazy load the Home component for better performance
const Home = lazy(() => import("./pages/Home"))

function App() {
  return (
    <Suspense fallback={<div className="loading">Loading...</div>}>
      <Home />
    </Suspense>
  )
}

export default App
