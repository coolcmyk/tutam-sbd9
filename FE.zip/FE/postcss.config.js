export default {
  plugins: {
    '@tailwindcss/postcss': {}, // Use the new package
    autoprefixer: {},
  },
}